﻿using System;
using System.Drawing;
using System.IO.Ports;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Threading;

namespace pc
{
    public partial class Form1 : Form
    {
        private const byte PACKET_HEADER = 0xAA;
        private const byte PACKET_FOOTER = 0x55;
        private const int MAX_PACKET_SIZE = 32;
        private const int MIN_PACKET_SIZE = 3;

        private enum PacketType
        {
            PACKET_TYPE_RGB = 0,
            PACKET_TYPE_MODE = 1
        }

        private struct Packet
        {
            public PacketType Type;
            public byte Length;
            public byte[] Data;
        }

        private SerialPort _serialPort;
        private Label[] labelRGBs;
        private List<byte> buffer = new List<byte>();
        private bool closing = false;
        private object lockObj = new object();

        public Form1()
        {
            InitializeComponent();
            _serialPort = new SerialPort();
            _serialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

            labelRGBs = new Label[] {
                labelRGB0, labelRGB1, labelRGB2, labelRGB3,
                labelRGB4, labelRGB5, labelRGB6, labelRGB7
            };

            foreach (var label in labelRGBs)
            {
                label.Click += LabelRGB_Click;
            }
        }

        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            lock (lockObj)
            {
                if (closing || !_serialPort.IsOpen) return;

                try
                {
                    SerialPort sp = (SerialPort)sender;
                    int bytesToRead = sp.BytesToRead;
                    byte[] tempBuffer = new byte[bytesToRead];
                    sp.Read(tempBuffer, 0, bytesToRead);
                    buffer.AddRange(tempBuffer);

                    ProcessBuffer();
                }
                catch (Exception ex)
                {
                    LogMessage($"Exception: {ex.Message}");
                }
            }
        }

        private void ProcessBuffer()
        {
            while (buffer.Count >= MIN_PACKET_SIZE)
            {
                if (buffer[0] != PACKET_HEADER)
                {
                    buffer.RemoveAt(0);
                    continue;
                }

                if (buffer.Count < 3) return;

                Packet packet = new Packet();
                packet.Type = (PacketType)buffer[1];
                packet.Length = buffer[2];

                if (buffer.Count < packet.Length + 3) return;

                if (packet.Length > MAX_PACKET_SIZE)
                {
                    buffer.RemoveRange(0, 3);
                    continue;
                }

                packet.Data = new byte[packet.Length];
                buffer.CopyTo(3, packet.Data, 0, packet.Length);

                buffer.RemoveRange(0, packet.Length + 3);

                DisplayPacket(packet);
                ProcessPacket(packet);
            }
        }

        private void DisplayPacket(Packet packet)
        {
            string packetContent = $"Type: {packet.Type}, Length: {packet.Length}, Data: {BitConverter.ToString(packet.Data)}";
            this.Invoke(new Action(() => {
                textBox1.AppendText(packetContent + Environment.NewLine);
            }));
        }

        private void ProcessPacket(Packet packet)
        {
            switch (packet.Type)
            {
                case PacketType.PACKET_TYPE_RGB:
                    if (packet.Length == 4)
                    {
                        byte index = packet.Data[0];
                        byte r = packet.Data[1];
                        byte g = packet.Data[2];
                        byte b = packet.Data[3];

                        this.Invoke(new Action(() => {
                            if (index >= 0 && index < labelRGBs.Length)
                            {
                                labelRGBs[index].BackColor = Color.FromArgb(r, g, b);
                            }
                        }));
                    }
                    break;

                case PacketType.PACKET_TYPE_MODE:
                    if (packet.Length == 1)
                    {
                        byte status = packet.Data[0];
                        this.Invoke(new Action(() => {
                            labelStatus.Text = $"Status: {status}";
                        }));
                    }
                    break;

                default:
                    LogMessage("Unknown packet type.");
                    break;
            }
        }

        private void LogMessage(string message)
        {
            this.Invoke(new Action(() => {
                textBox1.AppendText(message + Environment.NewLine);
            }));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            RefreshComPorts();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            closing = true;
            if (_serialPort.IsOpen)
            {
                _serialPort.DataReceived -= new SerialDataReceivedEventHandler(DataReceivedHandler);
                _serialPort.Close();
            }
        }

        private void buttonOpen_Click(object sender, EventArgs e)
        {
            string? selectedPort = comboBoxComPorts.SelectedItem?.ToString();
            if (selectedPort != null)
            {
                _serialPort.PortName = selectedPort;
                _serialPort.BaudRate = 9600;
                _serialPort.Parity = Parity.None;
                _serialPort.DataBits = 8;
                _serialPort.StopBits = StopBits.One;
                try
                {
                    _serialPort.Open();
                    buffer.Clear();

                    if (_serialPort.IsOpen)
                    {
                        _serialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

                        labelDeviceStatus.Text = "Connected";
                        labelDeviceStatus.BackColor = Color.Green;
                        LogMessage("Serial port opened successfully.");
                    }
                }
                catch (Exception ex)
                {
                    LogMessage($"Failed to open serial port: {ex.Message}");
                }
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            try
            {
                if (_serialPort.IsOpen)
                {
                    _serialPort.DataReceived -= new SerialDataReceivedEventHandler(DataReceivedHandler);
                    _serialPort.Close();
                    labelDeviceStatus.Text = "Disconnected";
                    labelDeviceStatus.BackColor = Color.Red;
                    LogMessage("Serial port closed.");
                }
            }
            catch (Exception ex)
            {
                LogMessage($"Exception during closing: {ex.Message}");
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            int dayOfWeek = (int)now.DayOfWeek + 1;
            string formattedTime = now.ToString("yyyy-MM-dd-") + dayOfWeek.ToString() + now.ToString("-HH:mm:ss");
            labelTime.Text = formattedTime;
        }

        private void RefreshComPorts()
        {
            comboBoxComPorts.Items.Clear();
            string[] comPorts = SerialPort.GetPortNames();
            comboBoxComPorts.Items.AddRange(comPorts);
        }

        private void LabelRGB_Click(object sender, EventArgs e)
        {
            Label label = sender as Label;
            DialogResult result = colorDialog1.ShowDialog();

            if (result == DialogResult.OK)
            {
                Color color = colorDialog1.Color;
                byte r = color.R;
                byte g = color.G;
                byte b = color.B;
                byte index = (byte)Array.IndexOf(labelRGBs, label);

                byte[] data = new byte[] { index, r, g, b };
                SendPacket(PacketType.PACKET_TYPE_RGB, data);
                label.BackColor = color;
            }
        }

        private void SendPacket(PacketType type, byte[] data)
        {
            if (_serialPort.IsOpen)
            {
                List<byte> bytes = new List<byte>
                {
                    PACKET_HEADER,
                    (byte)type,
                    (byte)data.Length
                };
                bytes.AddRange(data);
                bytes.Add(PACKET_FOOTER);

                try
                {
                    _serialPort.Write(bytes.ToArray(), 0, bytes.Count);
                    string packetContent = $"Sent - Type: {type}, Length: {data.Length}, Data: {BitConverter.ToString(data)}";
                    LogMessage(packetContent);
                }
                catch (Exception ex)
                {
                    LogMessage($"Failed to send packet: {ex.Message}");
                }
            }
            else
            {
                LogMessage("Serial port is not open.");
            }
        }
    }
}
