﻿namespace pc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            groupBoxDeviceConnect = new GroupBox();
            labelDeviceStatus = new Label();
            textDeviceStatus = new Label();
            buttonClose = new Button();
            buttonOpen = new Button();
            comboBoxComPorts = new ComboBox();
            timer = new System.Windows.Forms.Timer(components);
            groupBoxPassword = new GroupBox();
            buttonWriteEeprom = new Button();
            textBoxPassword = new TextBox();
            groupBoxNowTime = new GroupBox();
            buttonTimeUpdate = new Button();
            labelTime = new Label();
            groupBoxRgb = new GroupBox();
            labelRGB7 = new Label();
            labelRGB6 = new Label();
            labelRGB5 = new Label();
            labelRGB4 = new Label();
            labelRGB3 = new Label();
            labelRGB2 = new Label();
            labelRGB1 = new Label();
            labelRGB0 = new Label();
            textBox1 = new TextBox();
            colorDialog1 = new ColorDialog();
            labelStatus = new Label();
            groupBoxDeviceConnect.SuspendLayout();
            groupBoxPassword.SuspendLayout();
            groupBoxNowTime.SuspendLayout();
            groupBoxRgb.SuspendLayout();
            SuspendLayout();
            // 
            // groupBoxDeviceConnect
            // 
            groupBoxDeviceConnect.Controls.Add(labelStatus);
            groupBoxDeviceConnect.Controls.Add(labelDeviceStatus);
            groupBoxDeviceConnect.Controls.Add(textDeviceStatus);
            groupBoxDeviceConnect.Controls.Add(buttonClose);
            groupBoxDeviceConnect.Controls.Add(buttonOpen);
            groupBoxDeviceConnect.Controls.Add(comboBoxComPorts);
            groupBoxDeviceConnect.Location = new Point(6, 6);
            groupBoxDeviceConnect.Margin = new Padding(2);
            groupBoxDeviceConnect.Name = "groupBoxDeviceConnect";
            groupBoxDeviceConnect.Padding = new Padding(2);
            groupBoxDeviceConnect.Size = new Size(375, 125);
            groupBoxDeviceConnect.TabIndex = 0;
            groupBoxDeviceConnect.TabStop = false;
            groupBoxDeviceConnect.Text = "Device Connect";
            // 
            // labelDeviceStatus
            // 
            labelDeviceStatus.AutoSize = true;
            labelDeviceStatus.BackColor = Color.Red;
            labelDeviceStatus.Location = new Point(113, 90);
            labelDeviceStatus.Margin = new Padding(2, 0, 2, 0);
            labelDeviceStatus.Name = "labelDeviceStatus";
            labelDeviceStatus.Size = new Size(69, 15);
            labelDeviceStatus.TabIndex = 4;
            labelDeviceStatus.Text = "Disconnect";
            // 
            // textDeviceStatus
            // 
            textDeviceStatus.AutoSize = true;
            textDeviceStatus.Location = new Point(24, 90);
            textDeviceStatus.Margin = new Padding(2, 0, 2, 0);
            textDeviceStatus.Name = "textDeviceStatus";
            textDeviceStatus.Size = new Size(85, 15);
            textDeviceStatus.TabIndex = 3;
            textDeviceStatus.Text = "Device Status:";
            // 
            // buttonClose
            // 
            buttonClose.Location = new Point(244, 38);
            buttonClose.Margin = new Padding(2);
            buttonClose.Name = "buttonClose";
            buttonClose.Size = new Size(75, 23);
            buttonClose.TabIndex = 2;
            buttonClose.Text = "Close";
            buttonClose.UseVisualStyleBackColor = true;
            buttonClose.Click += buttonClose_Click;
            // 
            // buttonOpen
            // 
            buttonOpen.Location = new Point(149, 38);
            buttonOpen.Margin = new Padding(2);
            buttonOpen.Name = "buttonOpen";
            buttonOpen.Size = new Size(75, 23);
            buttonOpen.TabIndex = 1;
            buttonOpen.Text = "Open";
            buttonOpen.UseVisualStyleBackColor = true;
            buttonOpen.Click += buttonOpen_Click;
            // 
            // comboBoxComPorts
            // 
            comboBoxComPorts.FormattingEnabled = true;
            comboBoxComPorts.Location = new Point(32, 38);
            comboBoxComPorts.Margin = new Padding(2);
            comboBoxComPorts.Name = "comboBoxComPorts";
            comboBoxComPorts.Size = new Size(102, 23);
            comboBoxComPorts.TabIndex = 0;
            // 
            // timer
            // 
            timer.Enabled = true;
            timer.Tick += timer_Tick;
            // 
            // groupBoxPassword
            // 
            groupBoxPassword.Controls.Add(buttonWriteEeprom);
            groupBoxPassword.Controls.Add(textBoxPassword);
            groupBoxPassword.Location = new Point(6, 134);
            groupBoxPassword.Margin = new Padding(2);
            groupBoxPassword.Name = "groupBoxPassword";
            groupBoxPassword.Padding = new Padding(2);
            groupBoxPassword.Size = new Size(375, 125);
            groupBoxPassword.TabIndex = 1;
            groupBoxPassword.TabStop = false;
            groupBoxPassword.Text = "Password";
            // 
            // buttonWriteEeprom
            // 
            buttonWriteEeprom.Location = new Point(208, 45);
            buttonWriteEeprom.Margin = new Padding(2);
            buttonWriteEeprom.Name = "buttonWriteEeprom";
            buttonWriteEeprom.Size = new Size(125, 23);
            buttonWriteEeprom.TabIndex = 1;
            buttonWriteEeprom.Text = "Write EEPROM";
            buttonWriteEeprom.UseVisualStyleBackColor = true;
            // 
            // textBoxPassword
            // 
            textBoxPassword.Location = new Point(32, 45);
            textBoxPassword.Margin = new Padding(2);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.Size = new Size(127, 23);
            textBoxPassword.TabIndex = 0;
            // 
            // groupBoxNowTime
            // 
            groupBoxNowTime.Controls.Add(buttonTimeUpdate);
            groupBoxNowTime.Controls.Add(labelTime);
            groupBoxNowTime.Location = new Point(6, 263);
            groupBoxNowTime.Margin = new Padding(2);
            groupBoxNowTime.Name = "groupBoxNowTime";
            groupBoxNowTime.Padding = new Padding(2);
            groupBoxNowTime.Size = new Size(375, 125);
            groupBoxNowTime.TabIndex = 2;
            groupBoxNowTime.TabStop = false;
            groupBoxNowTime.Text = "Now Time";
            // 
            // buttonTimeUpdate
            // 
            buttonTimeUpdate.Location = new Point(237, 52);
            buttonTimeUpdate.Margin = new Padding(2);
            buttonTimeUpdate.Name = "buttonTimeUpdate";
            buttonTimeUpdate.Size = new Size(75, 23);
            buttonTimeUpdate.TabIndex = 5;
            buttonTimeUpdate.Text = "Update";
            buttonTimeUpdate.UseVisualStyleBackColor = true;
            // 
            // labelTime
            // 
            labelTime.AutoSize = true;
            labelTime.Location = new Point(32, 56);
            labelTime.Margin = new Padding(2, 0, 2, 0);
            labelTime.Name = "labelTime";
            labelTime.Size = new Size(161, 15);
            labelTime.TabIndex = 4;
            labelTime.Text = "YYYY-MM-DD-W-hh:mm:ss";
            // 
            // groupBoxRgb
            // 
            groupBoxRgb.Controls.Add(labelRGB7);
            groupBoxRgb.Controls.Add(labelRGB6);
            groupBoxRgb.Controls.Add(labelRGB5);
            groupBoxRgb.Controls.Add(labelRGB4);
            groupBoxRgb.Controls.Add(labelRGB3);
            groupBoxRgb.Controls.Add(labelRGB2);
            groupBoxRgb.Controls.Add(labelRGB1);
            groupBoxRgb.Controls.Add(labelRGB0);
            groupBoxRgb.Location = new Point(6, 390);
            groupBoxRgb.Margin = new Padding(2);
            groupBoxRgb.Name = "groupBoxRgb";
            groupBoxRgb.Padding = new Padding(2);
            groupBoxRgb.Size = new Size(375, 125);
            groupBoxRgb.TabIndex = 3;
            groupBoxRgb.TabStop = false;
            groupBoxRgb.Text = "RGB";
            // 
            // labelRGB7
            // 
            labelRGB7.AutoSize = true;
            labelRGB7.Location = new Point(10, 58);
            labelRGB7.Name = "labelRGB7";
            labelRGB7.Size = new Size(38, 15);
            labelRGB7.TabIndex = 7;
            labelRGB7.Text = "RGB7";
            // 
            // labelRGB6
            // 
            labelRGB6.AutoSize = true;
            labelRGB6.Location = new Point(54, 58);
            labelRGB6.Name = "labelRGB6";
            labelRGB6.Size = new Size(38, 15);
            labelRGB6.TabIndex = 6;
            labelRGB6.Text = "RGB6";
            // 
            // labelRGB5
            // 
            labelRGB5.AutoSize = true;
            labelRGB5.Location = new Point(98, 58);
            labelRGB5.Name = "labelRGB5";
            labelRGB5.Size = new Size(38, 15);
            labelRGB5.TabIndex = 5;
            labelRGB5.Text = "RGB5";
            // 
            // labelRGB4
            // 
            labelRGB4.AutoSize = true;
            labelRGB4.Location = new Point(142, 58);
            labelRGB4.Name = "labelRGB4";
            labelRGB4.Size = new Size(38, 15);
            labelRGB4.TabIndex = 4;
            labelRGB4.Text = "RGB4";
            // 
            // labelRGB3
            // 
            labelRGB3.AutoSize = true;
            labelRGB3.Location = new Point(186, 58);
            labelRGB3.Name = "labelRGB3";
            labelRGB3.Size = new Size(38, 15);
            labelRGB3.TabIndex = 3;
            labelRGB3.Text = "RGB3";
            // 
            // labelRGB2
            // 
            labelRGB2.AutoSize = true;
            labelRGB2.Location = new Point(230, 58);
            labelRGB2.Name = "labelRGB2";
            labelRGB2.Size = new Size(38, 15);
            labelRGB2.TabIndex = 2;
            labelRGB2.Text = "RGB2";
            // 
            // labelRGB1
            // 
            labelRGB1.AutoSize = true;
            labelRGB1.Location = new Point(274, 58);
            labelRGB1.Name = "labelRGB1";
            labelRGB1.Size = new Size(38, 15);
            labelRGB1.TabIndex = 1;
            labelRGB1.Text = "RGB1";
            // 
            // labelRGB0
            // 
            labelRGB0.AutoSize = true;
            labelRGB0.Location = new Point(318, 58);
            labelRGB0.Name = "labelRGB0";
            labelRGB0.Size = new Size(38, 15);
            labelRGB0.TabIndex = 0;
            labelRGB0.Text = "RGB0";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(386, 12);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(421, 503);
            textBox1.TabIndex = 5;
            // 
            // labelStatus
            // 
            labelStatus.AutoSize = true;
            labelStatus.Location = new Point(287, 90);
            labelStatus.Name = "labelStatus";
            labelStatus.Size = new Size(69, 15);
            labelStatus.TabIndex = 6;
            labelStatus.Text = "labelStatus";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(812, 522);
            Controls.Add(textBox1);
            Controls.Add(groupBoxRgb);
            Controls.Add(groupBoxNowTime);
            Controls.Add(groupBoxPassword);
            Controls.Add(groupBoxDeviceConnect);
            Margin = new Padding(2);
            Name = "Form1";
            Text = "113 學年度　工業類科學生技藝競　電腦修護職種　第二站　崗位號碼：00";
            Load += Form1_Load;
            groupBoxDeviceConnect.ResumeLayout(false);
            groupBoxDeviceConnect.PerformLayout();
            groupBoxPassword.ResumeLayout(false);
            groupBoxPassword.PerformLayout();
            groupBoxNowTime.ResumeLayout(false);
            groupBoxNowTime.PerformLayout();
            groupBoxRgb.ResumeLayout(false);
            groupBoxRgb.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBoxDeviceConnect;
        private ComboBox comboBoxComPorts;
        private Button buttonClose;
        private Button buttonOpen;
        private System.Windows.Forms.Timer timer;
        private Label labelDeviceStatus;
        private Label textDeviceStatus;
        private GroupBox groupBoxPassword;
        private TextBox textBoxPassword;
        private Button buttonWriteEeprom;
        private GroupBox groupBoxNowTime;
        private Label labelTime;
        private Button buttonTimeUpdate;
        private GroupBox groupBoxRgb;
        private TextBox textBox1;
        private ColorDialog colorDialog1;
        private Label labelRGB7;
        private Label labelRGB6;
        private Label labelRGB5;
        private Label labelRGB4;
        private Label labelRGB3;
        private Label labelRGB2;
        private Label labelRGB1;
        private Label labelRGB0;
        private Label labelStatus;
    }
}
